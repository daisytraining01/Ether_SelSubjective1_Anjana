package com.tests;

import java.util.HashMap;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.reusable.Common;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import com.pom.MercuryTravel_Registration_POM;
import com.reusable.Mercury_Reg;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MercuryTravels_StepDef {
	public Mercury_Reg reg = null;
	public WebDriver driver = null;
	public Actions action = null;
	public MercuryTravel_Registration_POM MercuryReg = null;
	private static HashMap<Integer, String> scenarios;
	public Common common = new Common();

	@Before
	public void beforeHook(Scenario scenario) {
		addScenario(scenario.getName());
		System.out.println("In Before Hooks");
	}

	private void addScenario(String scenario) {
		Thread currentThread = Thread.currentThread();
		int threadID = currentThread.hashCode();
		scenarios.put(threadID, scenario);
	}

	private synchronized String getScenario() {
		Thread currentThread = Thread.currentThread();
		int threadID = currentThread.hashCode();
		return scenarios.get(threadID);
	}

	public MercuryTravels_StepDef() {
		if (scenarios == null)
			scenarios = new HashMap<Integer, String>();
		System.setProperty("webdriver.chrome.driver", "C:\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		action = new Actions(driver);
		MercuryReg = new MercuryTravel_Registration_POM(driver);
		System.out.println("Inside Constructor");
		reg = new Mercury_Reg();
	}

	@Given("^Navigate to mercury tours registration page$")
	public void navigate_to_the_mercury_tours_registration_page() throws Throwable {

		reg.navigateToUrl(driver);
		System.out.println("Navigated to Mercury tours registration page");

	}

	@And("^verify if the page has been navigated as expected$")
	public void verify_if_the_page_has_been_navigated_as_expected() throws Throwable {
		System.out.println("Navigated to Mercury tours registration page successfully");

	}


	@And("^give the inputs on screen for registration and click on submit$")
	public void give_the_inputs_on_screen_for_registration_and_click_on_submit() throws Throwable {
		reg.feedInput(driver, MercuryReg, action, getScenario());
		System.out.println("Successfully entered input on screen");

	}

	@And("^verify if the screen navigates to the next screen$")
	public void verify_if_the_screen_navigates_to_the_next_screen() throws Throwable {
		reg.verifyNavigateTo_Success(driver, getScenario());

	}
	@And("^verify if the screen navigates to the next screen for \"([^\"]*)\"$")
	public void verify_if_the_screen_navigates_to_the_next_screen(int rowNum) throws FilloException {
		reg.verifyNavigateTo_Success(driver, getScenario());
		common.writeToFileFillo(rowNum,"Status",getScenario());
	}

	@Then("^take screenshots of the success or failure screen$")
	public void take_screenshots_of_the_success_or_failure_screen() throws Throwable {
		reg.takeScreenshot(driver, getScenario());
		System.out.println("Screenshots taken");


	}

	@When("^store values from parameters to variables \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void store_values_from_parameters_to_variables(String firstName, String lastName, String phone,
			String user_name, String addr, String city, String state, String postalCode, String country, String email,
			String password, String cnf_password) throws Throwable {
		reg.storeInVariable(firstName, lastName, phone, user_name, addr, city, state, postalCode, country, email,
				password, cnf_password);
		System.out.println("Value from parameters stored");

	}

	@When("^store values from excel using fillo for \"([^\"]*)\"$")
	public void store_values_from_parameters_to_variables(int rowNum) throws Throwable {
		String[] fields = {"firstName","lastname","phone","user_name","addr","city","state","postalCode","country","email","password","cnf_password"};
		System.out.println(common.readFromFile(rowNum,fields[0]));
		reg.storeInVariable(common.readFromFile(rowNum,fields[0]), common.readFromFile(rowNum,fields[1]), common.readFromFile(rowNum,fields[2]), common.readFromFile(rowNum,fields[3]), common.readFromFile(rowNum,fields[4]), common.readFromFile(rowNum,fields[5]), common.readFromFile(rowNum,fields[6]), common.readFromFile(rowNum,fields[7]), common.readFromFile(rowNum,fields[8]), common.readFromFile(rowNum,fields[9]),
				common.readFromFile(rowNum,fields[10]), common.readFromFile(rowNum,fields[11]));
		System.out.println("Value from excel stored");

	}

	@And("^close the browser$")
	public void closeBrowser() {
		reg.endTheSession(driver);
		System.out.println("Browser closed successfully");
	}

	@Then("^print all the country options from dropdown$")
	public void printCountryOptions() {
		reg.printCountries(driver);
		System.out.println("Session has ended");
	}

	@After
	public void after(Scenario scenario) {
		System.out.println("------------------------------");
		System.out.println(scenario.getName() + " Status - " + scenario.getStatus());
		System.out.println("------------------------------");
		System.out.println("In After Hooks");

	}


	public static void main(String args[]) throws FilloException {
		MercuryTravels_StepDef m = new MercuryTravels_StepDef();
		Fillo fillo = new Fillo();
		Connection connection = fillo.getConnection(System.getProperty("user.dir") + "\\TestDataSheet.xlsx");
		String strSelectQuerry = "Select * from  MercuryTours";
		Recordset recordset = connection.executeQuery(strSelectQuerry);
		System.out.println(recordset.getCount());
		for (int i = 1; i <= recordset.getCount(); i++) {
			m.reg.navigateToUrl(m.driver);
			System.out.println("Navigated to Mercury tours registration page");
			strSelectQuerry = "Select * from MercuryTours where Status='yes'";
			recordset = connection.executeQuery(strSelectQuerry);
			while (recordset.next()) {
				System.out.println(recordset.getField("firstName"));

				m.reg.storeInVariable(recordset.getField("firstName"), recordset.getField("lastName"), recordset.getField("phone"), recordset.getField("user_name"), recordset.getField("addr"), recordset.getField("city"), recordset.getField("state"), recordset.getField("postalCode"), recordset.getField("country"), recordset.getField("email"), recordset.getField("password"), recordset.getField("cnf_password"));
				System.out.println("Value from parameters stored");
				m.reg.feedInput(m.driver, m.MercuryReg, m.action, m.getScenario());
				System.out.println("Successfully entered input on screen");
				m.reg.verifyNavigateTo_Success(m.driver, m.getScenario());
				m.driver.close();
				recordset.close();
				connection.close();
			}
	}
	}
}
