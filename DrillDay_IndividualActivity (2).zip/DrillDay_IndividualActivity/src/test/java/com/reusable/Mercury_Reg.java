package com.reusable;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.pom.MercuryTravel_Registration_POM;

public class Mercury_Reg {

	public static String firstName = null;
	public static String lastName = null;
	public static String phone = null;
	public static String email = null;
	public static String addr = null;
	public static String city = null;
	public static String state = null;
	public static String postalCode = null;
	public static String country = null;
	public static String user_name = null;
	public static String password = null;
	public static String cnf_password = null;
	public static Common c = new Common();
	public boolean success = false;

	public void storeInVariable(String firstName, String lastName, String phone, String email, String addr, String city,
			String state, String postalCode, String country, String user_name, String password, String cnf_password) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.email = email;
		this.addr = addr;
		this.city = city;
		this.state = state;
		this.postalCode = postalCode;
		this.country = country;
		this.user_name = user_name;
		this.password = password;
		this.cnf_password = cnf_password;

	}

	public void takeScreenshot(WebDriver driver, String screenshotName) throws Throwable {
		c.takeScreenshot(driver, screenshotName + success);
	}

	public void navigateToUrl(WebDriver driver) {
		c.Navigate_To_URL(driver, "http://demo.guru99.com/test/newtours/register.php");
	}
	
	public void switchFrame(WebDriver driver,WebElement ele) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		if (wait.until(ExpectedConditions.visibilityOf(ele)).isDisplayed())
			driver.switchTo().frame(ele);
	}

	public void clickElement(WebDriver driver,WebElement ele) {
		new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(ele));
			ele.click();
	}
	public void feedInput(WebDriver driver, MercuryTravel_Registration_POM MercuryReg, Actions action,
			String scenarioName) {
		try {

			action.moveToElement(MercuryReg.getUserName());
			
			MercuryReg.getFirstName().sendKeys(firstName);
			switchFrame(driver,MercuryReg.getClose_iframe());
			
			
			clickElement(driver,MercuryReg.getCloseButton());
			
			driver.switchTo().parentFrame();
			
			MercuryReg.getLastName().sendKeys(lastName);
			
			MercuryReg.getPhone().sendKeys(phone);
			
			MercuryReg.getUserName().sendKeys(user_name);
			
			MercuryReg.getAddress().sendKeys(addr);
			
			MercuryReg.getCity().sendKeys(city);
			
			MercuryReg.getState().sendKeys(state);
			
			MercuryReg.getPostalCode().sendKeys(postalCode);
			
			Select countryDropDown = new Select(MercuryReg.getCountry());
			
			countryDropDown.selectByVisibleText(country);
			
			MercuryReg.getEmail().sendKeys(email);
			
			MercuryReg.getPassword().sendKeys(password);
			
			MercuryReg.getConfirmPassword().sendKeys(cnf_password);
			
			c.takeScreenshot(driver, scenarioName + "_DataEntered");

			clickElement(driver,MercuryReg.getSubmit());
			
			Thread.sleep(5000);
			
			switchFrame(driver,MercuryReg.getClose_iframe());

			clickElement(driver,MercuryReg.getCloseButton());
			
			driver.switchTo().parentFrame();
		} catch (Exception e) {
			e.printStackTrace();
			this.endTheSession(driver);
		}
	}

	public void closeTheCurrentBroswer(WebDriver driver) {
		driver.close();
	}

	public void endTheSession(WebDriver driver) {
		driver.quit();
	}

	public void verifyNavigateTo_Success(WebDriver driver, String scenario) {
		try {
			MercuryTravel_Registration_POM MercuryReg = new MercuryTravel_Registration_POM(driver);
			if (MercuryReg.getThankyou().isDisplayed()) {
				System.out.println("The screen was successfully navigated to the register_success page");
				success = true;
				if (scenario.contains("negative")) {
					Assert.assertFalse("Registration failed.try Again!", true);
					success = false;
				}
			}
		} catch (Exception e) {
			System.out.println("Registration failed.try Again!");
			driver.close();
			if (scenario.contains("positive"))
				Assert.assertFalse("Registration failed.try Again!", true);
		}
	}

	public void printCountries(WebDriver driver) {
		MercuryTravel_Registration_POM MercuryReg = new MercuryTravel_Registration_POM(driver);
		Select countryDropDown = new Select(MercuryReg.getCountry());
		List<WebElement> allOptions = countryDropDown.getOptions();
		System.out.println("The country options available are as follows:");
		for (WebElement ele : allOptions) {
			System.out.println(ele.getText());
		}

	}

}
