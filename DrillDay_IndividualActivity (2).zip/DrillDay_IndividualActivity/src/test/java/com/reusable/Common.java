package com.reusable;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Common {
	
	public void Navigate_To_URL( WebDriver driver, String url) {
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	public void takeScreenshot(WebDriver driver,String screenshotName) throws IOException, InterruptedException {
		String project_Dir = System.getProperty("user.dir");
		Thread.sleep(2000);
		TakesScreenshot scrShot = ((TakesScreenshot) driver);
		File srcFile = scrShot.getScreenshotAs(OutputType.FILE);
		File destFile = new File(project_Dir+"\\Screenshots\\"+screenshotName+".png");
		FileUtils.copyFile(srcFile, destFile);
	}
	public static String readFromFile(int rowNum,String field) throws Exception {
		String value="";
		try {

			Fillo fillo = new Fillo();
			Connection connection = fillo.getConnection(System.getProperty("user.dir") + "\\TestDataSheet.xlsx");
			String strSelectQuery = "Select * from sheet1 where RowNum=" + rowNum;
			Recordset recordset = connection.executeQuery(strSelectQuery);
			//System.out.println(recordset.getCount());
			while (recordset.next()) {
				value = recordset.getField(field);
			}
		}catch(Exception e){
			throw new Exception("Problem in getting data from Excel");
		}
		return value;
	}

	public static void writeToFileFillo(int rowNum,String field,String value) throws FilloException {
		Fillo fillo = new Fillo();
		Connection connection = fillo.getConnection(System.getProperty("user.dir") + "\\TestDataSheet.xlsx");
		String query = "UPDATE sheet1 Set "+field+"="+value+" where RowNum=" + rowNum;
		System.out.println(query);
		connection.executeUpdate(query);
		connection.close();

	}
	public static void main(String args[]) throws Exception {
		//String strSelectQuery = "Select * from  MercuryTours";
		System.out.println(readFromFile(1,"firstName"));
		writeToFileFillo(1,"ExeStatus","Success");
		/*for (int i = 1; i <= recordset.getCount(); i++) {
			strSelectQuery = "Select * from MercuryTours where Status='yes'";
			recordset = connection.executeQuery(strSelectQuery);
			while (recordset.next()) {
				System.out.println(recordset.getField("firstName"));
				recordset.close();
				connection.close();*/
	}
}
