package com.reusable;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrokenLinks {

	private static WebDriver driver = null;

	public static void main(String[] args) throws MalformedURLException, IOException, ClassCastException {

		System.setProperty("webdriver.chrome.driver", "C:\\Drivers\\chromedriver.exe");
		String homePage = "https://maveric-systems.com/";
		String url = "";
		HttpURLConnection connection = null;
		int respCode = 200;

		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(homePage);

		List<WebElement> links = driver.findElements(By.tagName("a"));
		for (WebElement ele : links)

			url = ele.getAttribute("href");

		if (url == null || url.isEmpty())
			System.out.println("URL is null");
		if(!url.startsWith(homePage)) {
			System.out.println("Skip url "+url);
		}
		else {
			connection = (HttpURLConnection) (new URL(url).openConnection());
			connection.setRequestMethod("HEAD");
			connection.connect();
			respCode = connection.getResponseCode();
			if (respCode >= 400) {
				System.out.println(url + " is a broken link");
			}
		}
		driver.quit();
	}

}
