package com.reusable;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WordPress_POI {

	public static WebDriver driver = null;

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		String url = "https://wordpress.com/?aff=58022&cid=8348279";
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		driver.findElement(By.xpath("//button[contains(text(),'Products')]")).click();
		if (driver.findElement(By.xpath("//div[@data-dropdown-name='products']")).isDisplayed()) {
			List<WebElement> links = driver.findElements(By.xpath("//div[@data-dropdown-name='products']/*//a"));
			System.out.println("There are " + links.size() + " links under products written to the excel");
			for (int i = 0; i < links.size(); i++) {
				writeToExcel("Products", i + 1, links.get(i).getText());
			}

		}
		driver.findElement(By.xpath("//button[contains(text(),'Features')]")).click();
		if (driver.findElement(By.xpath("//div[@data-dropdown-name='features']")).isDisplayed()) {
			List<WebElement> links = driver.findElements(By.xpath("//div[@data-dropdown-name='features']/*//a"));
			System.out.println("There are " + links.size() + " links under features written to the excel");
			for (int i = 0; i < links.size(); i++) {
				writeToExcel("Features", i + 1, links.get(i).getText());
			}

		}

		driver.findElement(By.xpath("//button[contains(text(),'Resources')]")).click();
		if (driver.findElement(By.xpath("//div[@data-dropdown-name='resources']")).isDisplayed()) {
			List<WebElement> links = driver.findElements(By.xpath("//div[@data-dropdown-name='resources']/*//a"));
			System.out.println("There are " + links.size() + " links under resources written to the excel");
			for (int i = 0; i < links.size(); i++) {
				writeToExcel("Resources", i + 1, links.get(i).getText());
			}

		}
		driver.close();
	}

	public static void writeToExcel(String column, int rownum, String value) throws NullPointerException {
		try {
			File f = new File(System.getProperty("user.dir") + "\\TestDataSheet.xlsx");

			FileInputStream fis = new FileInputStream(f);

			Workbook workbook = new XSSFWorkbook(fis);
			Sheet sheet = workbook.getSheet("WordPress");
			for (int j = 0;; j++) {
				Row row = sheet.getRow(0);
				Cell cell = row.getCell(j);
				if (cell.getStringCellValue().equalsIgnoreCase(column)) {
					row = sheet.getRow(rownum);
					if (row == null)
						row = sheet.createRow(rownum);
					cell = row.createCell(j);
					cell.setCellValue(value);
					FileOutputStream fos = new FileOutputStream(f);
					workbook.write(fos);
					fos.close();
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
