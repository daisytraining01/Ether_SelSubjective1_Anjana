package com.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/test/resources/FeatureFiles/MercuryTours/filloFetch.feature"},
				glue={"com.tests"},
				plugin = {"pretty","html:target/cucumber-report-html"},
				dryRun=false,
				monochrome = true,
				tags= {"@Positive_Scenario_Fillo"})

public class TestRunner {

}
